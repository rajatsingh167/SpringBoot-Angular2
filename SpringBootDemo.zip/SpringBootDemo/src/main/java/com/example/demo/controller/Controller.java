package com.example.demo.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.ProductRepository;
import com.example.demo.model.Product;

@RestController
@RequestMapping("api/v1/")
public class Controller {
	
	@Autowired
	ProductRepository repository;

	Product product=new Product();
	/*@CrossOrigin(origins="http://localhost:8808")
	@RequestMapping(value="Product" , method=RequestMethod.GET)
	Product[] getProduct(){
		
		product.setProductId(1);
		product.setProductName("Leaf Rake");
		product.setProductCode("GDN-0011");
		product.setReleaseDate(new Date());
		product.setDescription("Leaf rake with 48-inch wooden handle.");
		product.setPrice(10.02f);
		product.setStarRating(3.2f);
		product.setImageUrl("./app/assets/images/ng-vegas.png");
		
		return new Product[]{product};
		
	}*/

	@CrossOrigin(origins="http://localhost:8808")
	@RequestMapping(value="Productdb" , method=RequestMethod.GET)
	List<Product> getProductFromDb(){
		
		return  repository.findAll();
	}
	
	@CrossOrigin(origins="http://localhost:8808")
	@RequestMapping(value="addProducttodb" , method=RequestMethod.GET)
	Product addProducttoDb(){
		product.setProductId(1);
		product.setProductName("Leaf Rake");
		product.setProductCode("GDN-0011");
		product.setReleaseDate(new Date());
		product.setDescription("Leaf rake with 48-inch wooden handle.");
		product.setPrice(10.02f);
		product.setStarRating(3.2f);
		product.setImageUrl("./app/assets/images/ng-vegas.png");
		return  repository.saveAndFlush(product);
	}
}
