import { Component } from '@angular/core';

@Component ({  
   selector: 'my-app',  
   template: '<div>page Not</div>', 
})  
export class PageNotFoundComponent {  
} 