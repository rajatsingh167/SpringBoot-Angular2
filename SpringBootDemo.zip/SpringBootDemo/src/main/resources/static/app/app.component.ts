import {Component} from '@angular/core';
import{appService} from './app.service';
import {PaginatePipe, PaginationService} from 'ng2-pagination';


@Component({
selector: 'my-app',
template:`<div>Hello {{name}} test</div>
======================================================================
<ul>
<li><a [routerLink] = "['/Product']">Product</a></li>
<li><a [routerLink] = "['/Inventory']">Inventory</a></li>
<li><a [routerLink] = "['/Product-List']">Product-List</a></li>
</ul>
<router-outlet></router-outlet>
=======================================================================
`,
providers: [appService] 
})
export class AppComponent{ 
    name: string ='Angular';  
   
}