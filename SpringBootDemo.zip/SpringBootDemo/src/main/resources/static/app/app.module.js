"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var platform_browser_1 = require("@angular/platform-browser");
var core_1 = require("@angular/core");
var app_component_1 = require("./app.component");
var Inventory_component_1 = require("./Inventory.component");
var product_component_1 = require("./product.component");
var router_1 = require("@angular/router");
var NotFound_component_1 = require("./NotFound.component");
var forms_1 = require("@angular/forms");
var product_form_component_1 = require("./product-form.component");
var ng2_pagination_1 = require("ng2-pagination");
var customMultiplier_pipe_1 = require("./customMultiplier.pipe");
var convert_to_spaces_pipe_1 = require("./shared/convert-to-spaces.pipe");
var product_list_component_1 = require("./product/product-list.component");
var ProductService_service_1 = require("./product/ProductService.service");
var http_1 = require("@angular/common/http");
var star_component_1 = require("./shared/star.component");
var appRoutes = [
    { path: 'Product', component: product_component_1.Appproduct },
    { path: 'Inventory', component: Inventory_component_1.AppInventory },
    { path: 'Product-List', component: product_list_component_1.AppProductList },
    { path: '**', component: NotFound_component_1.PageNotFoundComponent }
];
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [platform_browser_1.BrowserModule, router_1.RouterModule.forRoot(appRoutes), forms_1.FormsModule, ng2_pagination_1.Ng2PaginationModule, http_1.HttpClientModule],
        declarations: [app_component_1.AppComponent, star_component_1.StarComponent, Inventory_component_1.AppInventory, product_list_component_1.AppProductList, product_component_1.Appproduct, NotFound_component_1.PageNotFoundComponent, product_form_component_1.ProductFormComponent, customMultiplier_pipe_1.MultiplierPipe, convert_to_spaces_pipe_1.ConvertToSpacesPipe],
        bootstrap: [app_component_1.AppComponent],
        providers: [ProductService_service_1.ProductService]
    }),
    __metadata("design:paramtypes", [])
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map