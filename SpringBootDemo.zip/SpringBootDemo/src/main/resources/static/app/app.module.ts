import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import{AppComponent} from './app.component';
import{AppInventory} from './Inventory.component';
import{Appproduct}from './product.component';
import { RouterModule, Routes } from '@angular/router';
import{PageNotFoundComponent}from './NotFound.component';
import { FormsModule } from '@angular/forms';
import { ProductFormComponent } from './product-form.component';
import {Ng2PaginationModule} from 'ng2-pagination';
import {MultiplierPipe} from './customMultiplier.pipe';
import { ConvertToSpacesPipe} from './shared/convert-to-spaces.pipe';
import{AppProductList} from './product/product-list.component';
import {ProductService} from './product/ProductService.service';
import {HttpClientModule} from '@angular/common/http';
import {StarComponent} from './shared/star.component';


const appRoutes:Routes=[
    { path: 'Product',       component: Appproduct },
    { path: 'Inventory',     component: AppInventory },
    { path: 'Product-List',  component: AppProductList },
    { path: '**',            component: PageNotFoundComponent } 
];

@NgModule({
    imports:      [ BrowserModule , RouterModule.forRoot(appRoutes) ,FormsModule ,Ng2PaginationModule ,HttpClientModule],
    declarations: [ AppComponent ,StarComponent, AppInventory,AppProductList ,Appproduct ,PageNotFoundComponent ,ProductFormComponent,MultiplierPipe ,ConvertToSpacesPipe],
    bootstrap:    [ AppComponent],
    providers:   [ProductService]
})

export class AppModule{ 

}

