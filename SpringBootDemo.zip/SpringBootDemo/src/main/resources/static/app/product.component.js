"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var app_service_1 = require("./app.service");
var Appproduct = (function () {
    function Appproduct(_appService) {
        this._appService = _appService;
        this.name = 'Angular';
        this.value = "";
        this.appTitle = 'Welcome';
        this.appList = [{
                "ID": 1,
                "Name": "One",
                "url": 'app/assets/images/ng-nl.png'
            },
            {
                "ID": 2,
                "Name": "Two",
                "url": 'app/assets/images/ng-vegas.png'
            }];
        this.Status = true;
    }
    Appproduct.prototype.ngOnInit = function () {
        this.value = this._appService.getApp();
    };
    Appproduct.prototype.clicked123 = function (event) {
        this.Status = !this.Status;
    };
    return Appproduct;
}());
Appproduct = __decorate([
    core_1.Component({
        //selector: 'my-app',
        template: "Products test\n   <Br>\n   =====================================================================\n   <h1>rajat </h1>\n   <div>{{value}}</div>\n   <div>{{value |slice:0:12}}</div>\n   ======================================================================\n   <product-form></product-form>\n   ======================================================================\n   <ul>\n   <li *ngFor = \"let item of collection | paginate: {\n      itemsPerPage: 5, currentPage: p }\"> ... </li>\n   </ul>\n   <pagination-controls (pageChange) = \"p = $event\"></pagination-controls>\n   =======================================================================\n   <table style=\"width:100%\">\n   <tr><th>Number</th><th colspan=\"2\">Name </th><th colspan=\"2\">Images </th></tr>\n   <div *ngFor = 'let lst of appList'> \n   <tr>1<td>{{lst.ID}}</td><td>{{lst.Name | uppercase}}</td><td><img [src] = 'lst.url'> </td></tr>\n   </div>\n   </table> \n   ========================================================================\n   <div>\n   <input [value] = \"name\" (input) = \"Rname = $event.target.value\">\n   {{Rname}}\n   </div>\n   \n   ========================================================================\n   <div> \n   {{Status}} <br>\n   <button (click) = \"clicked123()\">Click</button> \n   </div> \n   \n   ========================================================================\n   <br>Custom pipe for multiplication\n   <p>Multiplier: {{appList[1].ID |Multiply:60 }}</p>\n   <p>Multiplier: {{10| Multiply:20}}</p>\n   \n   \n   ",
    }),
    __metadata("design:paramtypes", [app_service_1.appService])
], Appproduct);
exports.Appproduct = Appproduct;
//# sourceMappingURL=product.component.js.map