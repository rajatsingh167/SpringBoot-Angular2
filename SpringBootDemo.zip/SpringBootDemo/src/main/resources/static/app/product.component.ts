import { Component } from '@angular/core';
import{appService} from './app.service';
import {PaginatePipe, PaginationService} from 'ng2-pagination';

@Component ({
   //selector: 'my-app',
   template: `Products test
   <Br>
   =====================================================================
   <h1>rajat </h1>
   <div>{{value}}</div>
   <div>{{value |slice:0:12}}</div>
   ======================================================================
   <product-form></product-form>
   ======================================================================
   <ul>
   <li *ngFor = "let item of collection | paginate: {
      itemsPerPage: 5, currentPage: p }"> ... </li>
   </ul>
   <pagination-controls (pageChange) = "p = $event"></pagination-controls>
   =======================================================================
   <table style="width:100%">
   <tr><th>Number</th><th colspan="2">Name </th><th colspan="2">Images </th></tr>
   <div *ngFor = 'let lst of appList'> 
   <tr>1<td>{{lst.ID}}</td><td>{{lst.Name | uppercase}}</td><td><img [src] = 'lst.url'> </td></tr>
   </div>
   </table> 
   ========================================================================
   <div>
   <input [value] = "name" (input) = "Rname = $event.target.value">
   {{Rname}}
   </div>
   
   ========================================================================
   <div> 
   {{Status}} <br>
   <button (click) = "clicked123()">Click</button> 
   </div> 
   
   ========================================================================
   <br>Custom pipe for multiplication
   <p>Multiplier: {{appList[1].ID |Multiply:60 }}</p>
   <p>Multiplier: {{10| Multiply:20}}</p>
   
   
   `,
})
export   class   Appproduct  {
    name: string ='Angular';  
    value: string = ""; 
    constructor(private _appService: appService) { } 
    ngOnInit(): void { 
        this.value = this._appService.getApp(); 
     }  

     appTitle: string = 'Welcome';
     
     appList: any[] = [{
        "ID": 1,
        "Name": "One",
        "url": 'app/assets/images/ng-nl.png'
     },
     {
        "ID": 2,
        "Name": "Two",
        "url": 'app/assets/images/ng-vegas.png'
    } ];

    Status: boolean = true; 
    clicked123(event) { 
       this.Status = !this.Status; 
    } 
}