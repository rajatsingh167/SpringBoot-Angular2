import { Injectable } from '@angular/core';
import { HttpClient , HttpErrorResponse} from '@angular/common/http';
import { Observable} from 'rxjs/Observable';
import {IProduct} from './IProduct.component'
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/observable/throw';



@Injectable()
export class ProductService{

   private _productUrl='http://localhost:8080/api/v1/Productdb';
   constructor( private _http :HttpClient){}

 getProduct() : Observable<IProduct[]>{
 return this._http.get<IProduct[]>(this._productUrl).do( data => console.log('ALL : '+JSON.stringify(data))).catch(this.handleError);
 }

private handleError(err:HttpErrorResponse) : any{
    return err;
}

}
