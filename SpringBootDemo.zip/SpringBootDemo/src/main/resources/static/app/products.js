"use strict";
var Product = (function () {
    function Product(productid, productname) {
        this.productid = productid;
        this.productname = productname;
    }
    return Product;
}());
exports.Product = Product;
//# sourceMappingURL=products.js.map