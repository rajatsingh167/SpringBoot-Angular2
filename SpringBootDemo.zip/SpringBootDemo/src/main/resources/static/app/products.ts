export class Product { 
    constructor ( 
       public productid: number, 
       public productname: string 
    ) {  } 
 }